package com.example.lab2

class Bird(name: String) : Animal(name), Bark {
    override fun printInfo() {
        super.printInfo()
        println("Type: Bird")
    }

    override fun voiceLoud() {
        println("$name sings loudly.")
    }

    override fun voiceQuiet() {
        println("$name sings quiet.")
    }
}