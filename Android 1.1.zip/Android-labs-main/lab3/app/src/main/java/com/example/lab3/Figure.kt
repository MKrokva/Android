package com.example.lab3

data class Figure(val width: Double, val height: Double) {

    private var _area: Double = width * height


    val area: Double
        get() = _area


    private fun setArea(value: Double) {
        _area = value
    }
}