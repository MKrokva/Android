package com.example.lab2

interface Bark {
    fun voiceLoud()
    fun voiceQuiet()
}