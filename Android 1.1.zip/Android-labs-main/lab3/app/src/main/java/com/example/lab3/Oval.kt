package com.example.lab3

data class Oval(val radiusX: Double, val radiusY: Double) : Shape()