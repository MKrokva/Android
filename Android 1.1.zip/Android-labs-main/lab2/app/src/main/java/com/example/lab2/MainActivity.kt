package com.example.lab2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.lab2.ui.theme.Lab2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dog = Dog("Рекс")
            val bird = Bird("Ластівка")
            val fish = Fish("Золота рибка")

            val myZoo = Zoo("Наш зоопарк")


            val lion = Animal("Лев")
            lion.setAge(5)

            val elephant = Animal("Слон")
            elephant.setAge(10)

            val giraffe = Animal("Жираф")
            giraffe.setAge(7)

            myZoo.addAnimal(lion)
            myZoo.addAnimal(elephant)
            myZoo.addAnimal(giraffe)

            myZoo.printAnimalsInfo()
        }
    }
}
