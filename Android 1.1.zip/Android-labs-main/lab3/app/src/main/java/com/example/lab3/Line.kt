package com.example.lab3

data class Line(val length: Double) : Shape()