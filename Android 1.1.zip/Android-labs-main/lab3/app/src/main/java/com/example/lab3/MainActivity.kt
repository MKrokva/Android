package com.example.lab3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.lab3.ui.theme.Lab3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            val figures = listOf(
                Figure(5.0, 10.0),
                Figure(3.0, 7.0),
                Figure(8.0, 4.0)
            )


            var totalArea = 0.0


            for (figure in figures) {
                totalArea += figure.area
            }


            println("total area: $totalArea")

            val shapes = listOf(
                Rectangle(5.0, 10.0),
                Oval(3.0, 7.0),
                Line(8.0),
                Rectangle(4.0, 6.0),
                Oval(2.0, 2.0),
                Line(5.0)
            )


            val rectangleCount = shapes.filterIsInstance<Rectangle>().size
            val ovalCount = shapes.filterIsInstance<Oval>().size
            val lineCount = shapes.filterIsInstance<Line>().size


            println("Кількість Rectangle: $rectangleCount")
            println("Кількість Oval: $ovalCount")
            println("Кількість Line: $lineCount")


            var rectangleCount2 = 0
            var ovalCount2 = 0
            var lineCount2 = 0

            for (shape in shapes) {
                when (shape) {
                    is Rectangle -> rectangleCount2++
                    is Oval -> ovalCount2++
                    is Line -> lineCount2++
                }
            }


            println("Кількість Rectangle: $rectangleCount2")
            println("Кількість Oval: $ovalCount2")
            println("Кількість Line: $lineCount2")

        }
    }
}

