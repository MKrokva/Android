package com.example.lab3

data class Rectangle(val width: Double, val height: Double) : Shape()