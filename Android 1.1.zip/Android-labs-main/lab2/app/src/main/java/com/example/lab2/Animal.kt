package com.example.lab2

open class Animal(val name: String) {
    private var age: Int = 0

    fun setAge(newAge: Int) {
        age = newAge
    }

    fun getAge(): Int {
        return age
    }


    fun fetchName(): String {
        return name
    }
    fun getInfo(): String {
        return "Тварина: $name, Вік: $age років"
    }
}