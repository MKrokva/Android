package com.example.lab2

class Dog(name: String) : Animal(name), Bark {
    override fun printInfo() {
        super.printInfo()
        println("Dog type")
    }

    override fun voiceLoud() {
        println("$name Barks loudly")
    }

    override fun voiceQuiet() {
        println("$name barks quiet")
    }
}