package com.example.lab3

sealed class Shape



