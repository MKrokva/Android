package com.example.lab2

class Fish(name: String) : Animal(name) {
    override fun printInfo() {
        super.printInfo()
        println("Type: Fish")
    }
}