package com.example.lab2

class Zoo(private val name: String) {
    private val animals = mutableListOf<Animal>()

    fun addAnimal(animal: Animal) {
        animals.add(animal)
    }

    fun printAnimalsInfo() {
        println("Вітаємо в $name!")
        println("Ось інформація про наших тварин:")
        for (animal in animals) {
            println(animal.getInfo())
        }
    }
}